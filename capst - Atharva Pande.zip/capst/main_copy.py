import os
import tiktoken
import subprocess
import pandas as pd
import streamlit as st
from load_keys import load_config
from sql_copy import SQL
from openai import AzureOpenAI
from sql_rep_copy import handle_user_input
from ui_copy import render_header, render_sidebar, render_chat_display, save_conversation
import copy

def launch_sqlite_web():
    """Launch SQLite Web on port 8080 for the current database."""
    db_path = os.path.join(os.getcwd(), "database1.db")
    if not os.path.exists(db_path):
        return "Error"


    # Launch SQLite-Web in background
    subprocess.Popen(
        ["sqlite_web", db_path, "--port", "8080"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        shell=True,
    )

# -------------------- MAIN --------------------
def main():
    config = load_config()
    if "messages" not in st.session_state:
        st.session_state.messages = []
    
    if "previous_files" not in st.session_state:
        st.session_state.previous_files = set()
    
    if not config["api_key"] or not config["endpoint"] or not config["deployment"]:
        st.error("Missing environment variables.")
        st.stop()


    if "selected_prompt_index" not in st.session_state:
        st.session_state.selected_prompt_index = None

    render_header()
    render_sidebar()

    # Initialize viewing_conversation flag
    if "viewing_conversation" not in st.session_state:
        st.session_state.viewing_conversation = False

    # If viewing a past conversation, skip file upload requirement
    
    
    #File uploader with session state key
    uploaded_files = st.file_uploader("📁 Upload CSV files", type=["csv"], accept_multiple_files=True,key=st.session_state.get("upload_key", "file_uploader"))
    if not uploaded_files and not st.session_state.viewing_conversation:
        st.info("Please upload one or more CSV files to begin.")
        st.stop()

    
    # # If files are uploaded, we're no longer just viewing
    # st.session_state.viewing_conversation = False


    if uploaded_files:
    # User uploaded files → we are starting fresh
        st.session_state.viewing_conversation = False
    else:
    # No new files uploaded → keep current viewing state
        pass


    # Inside your main() function, before comparing files
    # current_files = set(file.name for file in uploaded_files)
    current_files = set(file.name for file in uploaded_files) if uploaded_files else set()

    removed_files = st.session_state.previous_files - current_files


    # # -------------------- Initialize SQL --------------------
    try:
        sql = SQL(uploaded_files)
        for removed_file in removed_files:
            removed_table = sql._sanitize_table_name(removed_file)
            sql.drop_table(removed_table)

    except Exception as e:
        st.error(f"Error loading files: {e}")
        st.stop()
    
    st.session_state.previous_files = current_files

    # # -------------------- Prepare Schema --------------------
    
    summary_text = ""
    for file in uploaded_files:
        file.seek(0)
        filename = file.name
        table_name = sql._sanitize_table_name(filename)
        df = pd.read_csv(file)

        sample_data = df.head(20).to_dict(orient="records")
        column_types = df.dtypes.apply(lambda x: x.name).to_dict()

        summary_text += f"""
    📁 **{filename}** → Table `{table_name}`

    **Column Types:**
    {column_types}

    **Sample Rows:**
    {sample_data}

    ---
    """

    temperature = st.session_state.get("temperature", 0.0)
    client = AzureOpenAI(
        api_key=config["api_key"],
        azure_endpoint=config["endpoint"],
        api_version="2024-12-01-preview"
    )

    user_input = st.chat_input("💬 Ask me anything...")
    if user_input:
        handle_user_input(user_input, client, config["deployment"], temperature, sql, summary_text)
        save_conversation()
    
    if st.session_state.viewing_conversation and st.session_state.current_conversation_id:
    # Find the conversation in your saved list
        conv = next((c for c in st.session_state.conversations if c["id"] == st.session_state.current_conversation_id), None)
        if conv:
            st.session_state.messages = copy.deepcopy(conv["messages"])

    if st.session_state.viewing_conversation and st.session_state.messages:
        st.info("📖 Viewing past conversation. Upload new files to start a new analysis.")

    render_chat_display(user_input, client, config["deployment"], temperature, sql, summary_text)
    
    if st.session_state.viewing_conversation:
        st.stop()


    sql.close()

# -------------------- RUN --------------------
if __name__ == "__main__":
    main()