import pandas as pd
import streamlit as st
import tiktoken
from ui import save_conversation

def count_tokens(messages, model="gpt-4o-mini"):
    try:
        encoding = tiktoken.encoding_for_model(model)
    except KeyError:
        encoding = tiktoken.get_encoding("cl100k_base")  # fallback for unknown models

    num_tokens = 0
    for message in messages:
        num_tokens += 4  # every message has a role and content
        for key, value in message.items():
            num_tokens += len(encoding.encode(value))
    num_tokens += 2  # for assistant's reply priming
    return num_tokens


def generate_sql_query(user_input, client, deployment, temperature, schema):
    system_prompt = {
        "role": "system",
        "content": f"""
You are a data assistant you can also give general answers covesation that:
1. Generates valid SQLite SELECT queries based on user questions.
2. After the query is executed, you will be given the result.
3. Based on the result, generate Streamlit code to visualize it clearly.

The user may uploaded multiple datasets. Each dataset has been converted into a separate SQLite table. Below is the schema information for all tables: {schema}.

When the user asks a question:
- You must only generate **SELECT** queries. Do NOT generate queries that modify data such as DELETE, UPDATE, INSERT, DROP, ALTER, or TRUNCATE.
- If the user asks to modify, delete, or alter the table or its data, politely respond: "Only read-only queries are allowed".
- If the user asks a question **unrelated to the dataset**, politely respond: "Kindly ask a question related to the dataset. Click on 'View Database' to know about the data."
- First, respond ONLY with a valid SQL SELECT query.
- Always use **clear and meaningful column aliases** in the SELECT clause. For example, use `AS customer_name`, `AS total_orders`, or `AS average_spent`. Avoid raw function names like `count(*)` or `avg(...)` without aliases.
- Respond ONLY with a valid SQL SELECT statement. Do not include any formatting or backticks.
- Since you know all the tables and their content, you may need to perform joins or use subqueries to generate the required SQL queries.
- When filtering for records with no matching rows in another table, prefer using `LEFT JOIN` with `IS NULL` or `NOT EXISTS` over `NOT IN` to avoid NULL-related issues.
- When handling null values, use appropriate functions like `COALESCE()` to avoid errors or unexpected results.
- Always check data types and handle dates with format 'yyyy-mm-dd' consistently in queries.
- Ensure your queries handle possible nulls gracefully and avoid errors.
- Use aliases and clear naming for readability.
- Consider the **full schema and relationships** between tables — use appropriate JOINs and subqueries as needed.
- If the query involves filtering "customers who never ordered", avoid `NOT IN` (which fails with NULLs). Use `LEFT JOIN ... IS NULL` or `NOT EXISTS`.
- If you're using any derived fields (like full name with `first_name || ' ' || last_name`), make sure to include the full expression in the `GROUP BY` clause if selected.
- Always handle possible NULLs in aggregates using `COALESCE()`.
- Use `ROUND(..., 2)` to make numeric aggregates (like averages) user-friendly.
- Always check the column's datatype and ensure consistent date handling using `yyyy-mm-dd` format.


After the result is returned, respond ONLY with matplotlib code to visualize it using up to **two different charts** that best represent the data.
- The result of sql query is stored in variable called sql_result
- Only generate visualizations if the data is suitable (e.g., contains numeric columns, multiple rows, or categorical groupings).
- If the SQL result contains only one row and one column, or if the data is non-numeric, respond with: "Cannot visualize the result".
- If only one meaningful chart can be generated, return that chart and then the message: "Only one visualization is possible".
- There might be null values in the any row or column. So make sure to account for poosible errors that may arise. Generate the Sql query by accounting these things. 
- Use matplotlib for visualizations.
- Please return only matplotlib code that visualizes this result using a chart (e.g., bar_chart, line_chart, or matplotlib).
- Do not use st.table or st.dataframe. Do not include any explanation or text — only return valid Python code. Remove fomatting or backticks as well.
- You may use `matplotlib` if needed, but assume `st` and `pd` are already imported.
- If the SQL result contains only one row and one column, or if the data is non-numeric, respond with: "Cannot visualize the result".
- If the result is a list of tuples like `[('HCP_2995',), ('HCP_1439',)]`, convert it to a DataFrame before displaying.
- Do not include `import streamlit` or `import pandas` or better don't include import or any other backticks of formatting — assume they are already imported.
- Do not explain the code. Just return the code block.
"""
    }
    messages = [system_prompt, {"role": "user", "content": user_input}]
    response = client.chat.completions.create(
        model=deployment,
        messages=messages,
        temperature=temperature,
        max_tokens=4096
    )
    token_usage = response.usage
    prompt_tokens = token_usage.prompt_tokens
    completion_tokens = token_usage.completion_tokens
    total_tokens = token_usage.total_tokens
    print(f"[SQL GEN] Token usage: {total_tokens} (Prompt: {prompt_tokens}, Completion: {completion_tokens})")
    return response.choices[0].message.content.strip(), messages

def execute_sql_query(sql, query):
    return sql.sql_query(query)

def generate_visualization_code(client, deployment, temperature, messages, sql_result):
    messages.append({"role": "assistant", "content": messages[-1]["content"]})
    messages.append({"role": "user", "content": f"The result of the query is: {sql_result}"})
    response = client.chat.completions.create(
        model=deployment,
        messages=messages,
        temperature=temperature,
        max_tokens=1500
    )
    token_usage = response.usage
    print(f"[VISUALIZATION] Token usage: {token_usage.total_tokens}")
    return response.choices[0].message.content.strip()

def display_sql_result(sql_result, columnss):
    st.markdown("#### 📋 SQL Result Table")
    try:
        df = pd.DataFrame(sql_result, columns=columnss)
        st.table(df)
        return df
    except Exception as e:
        st.warning(f"Could not display SQL result as table: {e}")
        return None

def generate_narrative_summary(client, deployment, temperature, user_input, sql_result):
    if isinstance(sql_result, list):
        try:
            sql_result = pd.DataFrame(sql_result)
        except Exception as e:
            st.error(f"Failed to convert SQL result to DataFrame: {e}")
            return
    narrative_prompt = f"""
You are a data analyst assistant. Based on the user's question and the SQL query result, generate a concise, human-readable narrative summary.

User Question:
{user_input}

SQL Query Result:
{sql_result}

Instructions:
- Summarize the key insights from the data in the context of the user's question.
- Be clear, concise, and avoid repeating the table verbatim.
- Highlight trends, comparisons, or notable values if applicable.
- The summary needs to be explained in brief to a "non-technical" user. So tell the result in a story form.
"""
    response = client.chat.completions.create(
        model=deployment,
        messages=[
            {"role": "system", "content": "You are a helpful data analyst assistant."},
            {"role": "user", "content": narrative_prompt}
        ],
        temperature=temperature,
        max_tokens=300
    )
    token_usage = response.usage
    print(f"[SUMMARY] Token usage: {token_usage.total_tokens}")
    return response.choices[0].message.content.strip()


def handle_user_input(user_input, client, deployment, temperature, sql, schema):
    if not user_input:
        return

    # Store user message
    st.session_state.messages.append({"role": "user", "content": user_input})

    with st.spinner("Generating SQL..."):
        sql_query, messages = generate_sql_query(user_input, client, deployment, temperature, schema)

    # Handle restricted or irrelevant queries
    if sql_query.startswith("Only"):
        st.session_state.messages.append({
            "role": "assistant",
            "content": "🚨 Altering/modification not allowed",
            "query": sql_query,
            "res": [],
            "summa": "",
            "viz_code": "",
            "columns": []
        })

        return

    if sql_query.startswith("Kindly"):
        final_message = "Kindly ask a question related to the dataset. Click on 'View Database' to know about the data."
        st.session_state.messages.append({
            "role": "assistant",
            "content": "🚨 " + final_message.capitalize(),
            "query": final_message,
            "res": [],
            "summa": "",
            "viz_code": "",
            "columns": []
        })
    
        return

    # Run SQL
    sql_result, columnss = execute_sql_query(sql, sql_query)
    if sql_result == "NO such value":
        st.warning("⚠️ No results found for your query.")
        return

    # Generate summary
    summary = generate_narrative_summary(client, deployment, temperature, user_input, sql_result)

    # Generate visualization code
    viz_code = generate_visualization_code(client, deployment, temperature, messages, sql_result)
    viz_code = viz_code.strip().replace("```python", "").replace("```", "")

    # Append full assistant message
    st.session_state.messages.append({
        "role": "assistant",
        "content": sql_query,   # Optionally you can put full message here if needed
        "query": sql_query,
        "res": sql_result,
        "summa": summary,
        "viz_code": viz_code,
        "columns": columnss
    })

    # Save conversation snapshot (if you implemented this)
    save_conversation()
