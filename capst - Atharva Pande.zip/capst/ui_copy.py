import streamlit as st
import subprocess
import webbrowser
from datetime import datetime
from sql_rep_copy import display_sql_result,execute_sql_query, generate_sql_query, generate_visualization_code, generate_narrative_summary
import pandas as pd
import copy
import matplotlib.pyplot as plt
import os
import time

def render_header():
    """Render the application header with modern styling"""
    st.markdown("""
        <style>
        .main-header {
            padding: 1.5rem 0;
            text-align: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .main-header h1 {
            margin: 0;
            font-size: 2.5rem;
            font-weight: 700;
        }
        .main-header p {
            margin: 0.5rem 0 0 0;
            font-size: 1.1rem;
            opacity: 0.95;
        }
        </style>
        <div class="main-header">
            <h1>DataSensei</h1>
            <p>Ask questions about your data and get instant insights</p>
        </div>
    """, unsafe_allow_html=True)

def render_sidebar():
    with st.sidebar:
        st.subheader("⚙️ Model Settings")
        st.session_state.temperature = st.slider("Set temperature", 0.0, 1.0)
        st.divider()

        st.subheader("📊 View Tables")
        if st.button("🧭 Open SQLite Web"):
            try:
                # Launch sqlite_web in the background
                subprocess.Popen(["sqlite_web", "database1.db", "--host", "127.0.0.1", "--port", "8080"])
                webbrowser.open_new_tab("http://127.0.0.1:8080")
                st.success("SQLite Web launched at http://127.0.0.1:8080")
            except Exception as e:
                st.error(f"Failed to launch SQLite Web: {e}")

        # Initialize conversations if not exists
        if "conversations" not in st.session_state:
            st.session_state.conversations = []
        if "current_conversation_id" not in st.session_state:
            st.session_state.current_conversation_id = None

        st.header("💬 Chat History")
        st.markdown("""
            <style>
            /* New Chat button styling */
            .stButton > button[kind="primary"] {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
                border: none !important;
                color: white !important;
            }
            .stButton > button[kind="primary"]:hover {
                background: linear-gradient(135deg, #5568d3 0%, #65398b 100%) !important;
                box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4) !important;
            }
            /* Secondary button (inactive conversations) */
            .stButton > button[kind="secondary"] {
                background: white !important;
                border: 1px solid #e0e0e0 !important;
                color: #2c3e50 !important;
            }
            .stButton > button[kind="secondary"]:hover {
                background: #f5f5f5 !important;
                border-color: #667eea !important;
            }
            </style>
        """, unsafe_allow_html=True)


        # New Chat Button
        if st.button("➕ New Chat", use_container_width=True, type="primary"):
            st.session_state.current_conversation_id = None
            st.session_state.messages = []
            # Clear uploaded files
            if 'uploaded_files' in st.session_state:
                del st.session_state['uploaded_files']
            # Invalidate previous uploaded files by changing key
            st.session_state.upload_key = str(time.time())  # or use a counter
            st.rerun()
        st.markdown("<br>", unsafe_allow_html=True)


        # Display conversation history
        if st.session_state.conversations:
            st.markdown("**Recent Conversations:**")
            
            # Add custom CSS for conversation items
            st.markdown("""
                <style>
                .conversation-item {
                    padding: 0.75rem;
                    margin: 0.5rem 0;
                    border-radius: 8px;
                    cursor: pointer;
                    transition: all 0.2s;
                    border: 1px solid #e0e0e0;
                    background: white;
                }
                .conversation-item:hover {
                    background: #f5f5f5;
                    border-color: #667eea;
                }
                .conversation-item.active {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    border-color: #667eea;
                }
                .conversation-title {
                    font-weight: 600;
                    font-size: 0.9rem;
                    margin-bottom: 0.25rem;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                }
                .conversation-time {
                    font-size: 0.75rem;
                    opacity: 0.7;
                }
                </style>
            """, unsafe_allow_html=True)

            
            # Display each conversation
            for idx, conv in enumerate(reversed(st.session_state.conversations)):
                conv_id = conv["id"]
                first_query = conv["first_query"]
                timestamp = conv["timestamp"]
                
                # Truncate long queries
                display_query = first_query if len(first_query) <= 50 else first_query[:47] + "..."
                
                # Check if this is the active conversation
                is_active = conv_id == st.session_state.current_conversation_id
                
                # Create a button for each conversation
                button_label = f"💬 {display_query}"
                if st.button(
                    button_label,
                    key=f"conv_{conv_id}_{idx}",
                    use_container_width=True,
                    type="primary" if is_active else "secondary"
                ):
                    # Load this conversation - create deep copy of each message
                    st.session_state.current_conversation_id = conv_id
                    st.session_state.messages = copy.deepcopy(conv["messages"])
                    # Mark that we want to view this conversation
                    st.session_state.viewing_conversation = True
                    st.rerun()
                
                # Show timestamp below button
                st.caption(f"🕒 {timestamp}")
        else:
            st.info("No conversations yet. Start asking questions!")
        
        st.divider()

        if st.button("🗑️ Clear All History", use_container_width=True, type="secondary"):
            st.session_state.conversations = []
            st.session_state.current_conversation_id = None
            st.session_state.messages = []
            # st.rerun()

        st.markdown("---")

def save_conversation():
    """Save the current conversation to history"""
    # Find the first user message
    first_user_message = None
    for msg in st.session_state.messages:
        if msg["role"] == "user":
            first_user_message = msg["content"]
            break
    
    if not first_user_message:
        return
    
    # Check if this is a new conversation or updating existing
    if st.session_state.current_conversation_id is None:
        # Create new conversation
        conv_id = f"conv_{len(st.session_state.conversations)}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        st.session_state.current_conversation_id = conv_id
        
        conversation = {
            "id": conv_id,
            "first_query": first_user_message,
            "timestamp": datetime.now().strftime("%b %d, %I:%M %p"),
            "messages": copy.deepcopy(st.session_state.messages)
        }
        st.session_state.conversations.append(conversation)
    else:
        # Update existing conversation
        for conv in st.session_state.conversations:
            if conv["id"] == st.session_state.current_conversation_id:
                conv["messages"] = copy.deepcopy(st.session_state.messages)
                conv["timestamp"] = datetime.now().strftime("%b %d, %I:%M %p")
                break


def render_chat_display(user_input, client, deployment, temperature, sql, schema):
    """Render the chat messages with improved styling"""
    
    # Add custom CSS for better chat display
    st.markdown("""
        <style>
        /* Chat container styling */
        .chat-container {
            margin: 2rem 0;
        }
        
        /* User message styling */
        .user-message {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1.2rem 1.5rem;
            border-radius: 18px 18px 4px 18px;
            margin: 1rem 0 1rem auto;
            max-width: 80%;
            box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
            animation: slideInRight 0.3s ease-out;
        }
        
        .user-message-label {
            font-weight: 600;
            font-size: 0.85rem;
            opacity: 0.9;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .user-message-content {
            font-size: 1rem;
            line-height: 1.6;
        }
        
        /* Assistant message styling */
        .assistant-message {
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            padding: 1.2rem 1.5rem;
            border-radius: 4px 18px 18px 18px;
            margin: 1rem auto 1rem 0;
            max-width: 80%;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            animation: slideInLeft 0.3s ease-out;
        }
        
        .assistant-message-label {
            font-weight: 600;
            font-size: 0.85rem;
            color: #667eea;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .assistant-message-content {
            font-size: 1rem;
            line-height: 1.6;
            color: #2c3e50;
        }
        
        /* SQL Query Box - Updated color scheme */
        .sql-query-box {
            background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
            padding: 1.2rem;
            border-radius: 10px;
            margin: 1rem 0;
            border-left: 4px solid #2196f3;
            box-shadow: 0 2px 8px rgba(33, 150, 243, 0.2);
        }
        
        .sql-label {
            color: #1565c0;
            font-weight: 600;
            margin-bottom: 0.75rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.95rem;
        }
        
        .sql-query-content {
            background: white;
            padding: 1rem;
            border-radius: 6px;
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
            color: #1565c0;
            overflow-x: auto;
            border: 1px solid #90caf9;
            line-height: 1.6;
        }
        
        /* Result sections */
        .result-section {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            margin: 1.5rem 0;
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
            border: 1px solid #e9ecef;
        }
        
        .result-header {
            font-size: 1.1rem;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid #f0f0f0;
        }
        
        /* Summary box */
        .summary-box {
            background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);
            padding: 1.2rem;
            border-radius: 10px;
            border-left: 4px solid #9c27b0;
            margin: 1rem 0;
            box-shadow: 0 2px 8px rgba(156, 39, 176, 0.2);
        }
        
        .summary-label {
            color: #6a1b9a;
            font-weight: 600;
            font-size: 0.95rem;
            margin-bottom: 0.75rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .summary-content {
            color: #4a148c;
            line-height: 1.7;
            font-size: 0.95rem;
            background: rgba(255, 255, 255, 0.6);
            padding: 0.75rem;
            border-radius: 6px;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
        
        /* Animations */
        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        /* Message spacing */
        .message-group {
            margin-bottom: 2rem;
        }
        
        /* Divider */
        .message-divider {
            height: 1px;
            background: linear-gradient(90deg, transparent, #e0e0e0, transparent);
            margin: 2rem 0;
        }
        
        /* Visualization container */
        .viz-container {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            margin: 1rem 0;
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
        }
        </style>
    """, unsafe_allow_html=True)
    
    if not st.session_state.messages:
        # Empty state
        st.markdown("""
            <div style="text-align: center; padding: 4rem 2rem; color: #6c757d;">
                <h3 style="color: #495057; margin-bottom: 1rem;">👋 Ready to explore your data!</h3>
                <p style="font-size: 1.1rem; margin-bottom: 0.5rem;">Ask me questions like:</p>
                <ul style="list-style: none; padding: 0; margin-top: 1rem;">
                    <li style="padding: 0.5rem;">💡 "Show me the top 10 products by sales"</li>
                    <li style="padding: 0.5rem;">📊 "What's the average price by category?"</li>
                    <li style="padding: 0.5rem;">📈 "Compare sales trends over time"</li>
                </ul>
            </div>
        """, unsafe_allow_html=True)
        return
    
    # Display conversation header
    st.markdown("### 💬 Conversation")
    st.markdown("<div class='message-divider'></div>", unsafe_allow_html=True)
    
    # Group messages for better organization
    i = 0
    while i < len(st.session_state.messages):
        msg = st.session_state.messages[i]

        if msg["role"] == "user":
            st.markdown(f"""
                <div class="user-message">
                    <div class="user-message-label">👤 You</div>
                    <div class="user-message-content">{msg['content']}</div>
                </div>
            """, unsafe_allow_html=True)

        elif msg.get("res") == [] and msg.get("summa") == "" and msg.get("viz_code") == "":
            # Just show the assistant warning or info message
            st.markdown(f"""<div style="background-color:#fff3cd; 
                        color:#856404; 
                        padding:1em; 
                        border:1px solid #ffeeba; border-radius:5px;">
                        🚨 {msg["content"]}
                        </div>""", unsafe_allow_html=True)

        elif msg["role"] == "assistant":
            sql_query = msg.get("query", msg["content"])
            sql_res = msg.get("res", [])
            summary = msg.get("summa", "")
            viz_code = msg.get("viz_code", "")

            # Display SQL query if present
            if sql_query and any(kw in sql_query.upper() for kw in ["SELECT", "FROM"]):
                st.markdown(f"""
                    <div class="sql-query-box">
                        <div class="sql-label">🧠 Generated SQL Query</div>
                        <div class="sql-query-content">{sql_query}</div>
                    </div>
                """, unsafe_allow_html=True)

            # Display SQL result table
            if sql_res:
                df = display_sql_result(sql_res, msg.get("columns", []))  # columns can be saved optionally

            # Display summary
            if summary:
                st.markdown(f"""
                    <div class="summary-box">
                        <div class="summary-label">📝 Insights & Summary</div>
                        <div class="summary-content">{summary}</div>
                    </div>
                """, unsafe_allow_html=True)

            # Display visualization
            if viz_code:
                st.markdown("#### 📊 Visualization")
                # st.code(viz_code, language="python")

                if "Cannot visualize the result" in viz_code:
                    st.code(viz_code, language="python")
                else:
                    try:
                        viz_code_clean = viz_code.strip().replace("```python", "").replace("```", "").replace("plt.show()","")
                        pre_viz = {"st": st, "pd": pd, "plt": plt, "sql_result": sql_res}
                        exec(viz_code_clean, pre_viz)
                        fig = plt.gcf()
                        if fig.axes:
                            st.pyplot(fig)
                        else:
                            st.warning("No axes were available to plot.")
                        plt.close(fig)
                    except Exception as e:
                        st.warning(f"Visualization code has a syntax error: {e}")

        i += 1

        
        # Add spacing between conversation groups
        if i < len(st.session_state.messages):
            next_msg = st.session_state.messages[i]
            if msg["role"] == "user" or (msg["role"] == "assistant" and next_msg["role"] == "user"):
                st.markdown("<div style='margin: 1.5rem 0'></div>", unsafe_allow_html=True)